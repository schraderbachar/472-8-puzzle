package aima.core.probability.proposition;

/**
 * Indicator interface used to identify unary sentences.
 * 
 * @author Ciaran O'Reilly
 */
public interface UnarySentenceProposition extends SentenceProposition {

}
