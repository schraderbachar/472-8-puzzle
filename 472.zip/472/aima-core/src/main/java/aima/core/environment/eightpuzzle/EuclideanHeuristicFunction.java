package aima.core.environment.eightpuzzle;

import aima.core.search.framework.evalfunc.HeuristicFunction;
import aima.core.util.datastructure.XYLocation;

/**
 * @author JJ SchraderBachar
 * 
 */
public class EuclideanHeuristicFunction implements HeuristicFunction {

	public double h(Object state) {
		EightPuzzleBoard board = (EightPuzzleBoard) state;
		int retVal = 0;
		XYLocation loc = board.getLocationOf(0);
		retVal += evaluateEuclidenaDistanceOf(0, loc);

		return retVal;

	}

	/**
	 * Calculates the Euclidean Distance based on where the 0 is in the state
	 * 
	 * @param i   0 in the board
	 * @param loc location of 0 on the board
	 * @return Euclidean distance from where 0 is.
	 */
	public int evaluateEuclidenaDistanceOf(int i, XYLocation loc) {
		int retVal = -1;
		int xpos = loc.getXCoOrdinate();
		int ypos = loc.getYCoOrdinate();
		switch (i) {
			case 1:
				retVal = (int) Math.sqrt(Math.pow(Math.abs(xpos - 0), 2) + Math.pow(Math.abs(ypos - 1), 2));
				break;
			case 2:
				retVal = (int) Math.sqrt(Math.pow(Math.abs(xpos - 0), 2) + Math.pow(Math.abs(ypos - 2), 2));
				break;
			case 3:
				retVal = (int) Math.sqrt(Math.pow(Math.abs(xpos - 1), 2) + Math.pow(Math.abs(ypos - 0), 2));
				break;
			case 4:
				retVal = (int) Math.sqrt(Math.pow(Math.abs(xpos - 1), 2) + Math.pow(Math.abs(ypos - 1), 2));
				break;
			case 5:
				retVal = (int) Math.sqrt(Math.pow(Math.abs(xpos - 1), 2) + Math.pow(Math.abs(ypos - 2), 2));
				break;
			case 6:
				retVal = (int) Math.sqrt(Math.pow(Math.abs(xpos - 2), 2) + Math.pow(Math.abs(ypos - 0), 2));
				break;
			case 7:
				retVal = (int) Math.sqrt(Math.pow(Math.abs(xpos - 2), 2) + Math.pow(Math.abs(ypos - 1), 2));
				break;
			case 8:
				retVal = (int) Math.sqrt(Math.pow(Math.abs(xpos - 2), 2) + Math.pow(Math.abs(ypos - 2), 2));
				break;

		}
		return retVal;
	}
}